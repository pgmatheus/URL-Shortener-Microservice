require('dotenv').config();
const express = require('express');
const cors = require('cors');
const app = express();
const bodyParser = require("body-parser");
const mongoose = require('mongoose');
mongoose.connect(process.env.DB_URI);

// Basic Configuration
const port = process.env.PORT || 3000;

function validURL(str) {
  var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
    '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
    '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
    '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
    '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
    '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
  return !!pattern.test(str);
}

const Url = new mongoose.Schema({
  original_url: String,
  short_url: Number
});

const url = mongoose.model('url', Url);

function createUrl(arr) {
  let a = new url(arr);
  a.save(function (err) {
  if (err) return handleError(err);
  })
} 

//createUrl({original_url: 'https://freeCodeCamp.org',    short_url: 0})

app.use(cors());

app.use('/public', express.static(`${process.cwd()}/public`));

app.get('/', function(req, res) {
  res.sendFile(process.cwd() + '/views/index.html');
});

// Your first API endpoint
app.get('/api/hello', function(req, res) {
  res.json({ greeting: 'hello API' });
});

app.listen(port, function() {
  console.log(`Listening on port ${port}`);
});

var findUrl = function (urlsName, done) {
  url.find({name: urlsName}, function (err,pf){
    if (err) return console.log(err);
    done(null, pf);
  });
};

app.post('/api/shorturl', bodyParser.urlencoded({extended:false}),(req,res) => {
  let inputUrl = req.body;
  let n = 0;

  if (validURL(req.body['url']))
  {


   //{original_url: 'https://freewCodeCamp.org'}
  url.findOne({})
    .sort({short_url: 'desc'})
    .exec((err,doc) => {
      if (err) return console.log(err);
      console.log(n)
        n = doc.short_url+1   
  })
  
  url.findOne({original_url: req.body['url']})
    .exec((err,doc1) => {
      if (err) return console.log(err);
            if (doc1 != undefined){
              if (err) return console.log(err);               
                res.json({original_url: doc1.original_url,
            short_url: doc1.short_url})  
            } else{
              createUrl({original_url: req.body['url'], short_url: n});
              res.json({original_url: req.body['url'], short_url: n});              
            }
    })
}
else{
  res.json({error: 'invalid url'})
}
})


app.get("/api/shorturl/:input?", function (req, res) {
  let a = req.params.input;
  url.findOne({short_url: a})  
  .exec((err,res2) => {
    if (!err && res2 != undefined){      
    res.redirect(res2.original_url)
    }
    //if (err) resturn console.log(err);  
  })
})











